create trigger insertpassword
  before INSERT
  on tb_user
  for each row
  begin
set new.password=md5(new.password);
end;

